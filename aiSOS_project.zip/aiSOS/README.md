# aiSOS 🚀

**aiSOS** — минималистичная операционная система на Rust (`no_std`) без Linux, с поддержкой AI-инференса, NVMe-дисков, сетей на DPDK и GPU-инференса через NVIDIA Tesla.

---

## 📦 Структура проекта

```
rust_server_os/
├── boot/            # UEFI-загрузчик
├── kernel/          # Ядро ОС на Rust
├── rpk/             # .rpk модули, включая gemma_gpu
└── README.md
```

---

## 💻 Требования к железу

| Компонент | Модель |
|-----------|--------|
| CPU       | AMD Ryzen 9 5950X (16 ядер) |
| RAM       | 32+ GB DDR4 |
| SSD       | NVMe SSD (например, Samsung 970 EVO Plus) |
| GPU       | NVIDIA Tesla K80 (опционально) |
| Сеть      | Intel X550-T2 (10G) |

---

## 🛠 Сборка операционной системы

> Убедись, что установлен nightly Rust и `cargo-xbuild`:

```bash
rustup install nightly
rustup component add rust-src --toolchain nightly
cargo install cargo-xbuild
```

1. Склонируй репозиторий:

```bash
git clone https://github.com/yourname/rust_server_os.git
cd rust_server_os
```

2. Собери загрузчик и ядро:

```bash
cd boot
cargo build --release --target x86_64-unknown-uefi

cd ../kernel
cargo xbuild --release --target x86_64-my_os.json
```

3. Создай EFI-диск или ISO:

```bash
mkdir -p iso/EFI/BOOT
cp ../boot/target/x86_64-unknown-uefi/release/bootx64.efi iso/EFI/BOOT/
cp target/x86_64-my_os/release/kernel iso/kernel.elf
grub-mkrescue -o rustos.iso iso/
```

---

## 💽 Установка

1. Запиши `rustos.iso` на флешку или виртуальный диск:

```bash
sudo dd if=rustos.iso of=/dev/sdX bs=4M status=progress
```

2. Запусти на реальном сервере или в QEMU:

```bash
qemu-system-x86_64 -m 4096 -cdrom rustos.iso -enable-kvm
```

---

## 🌐 Использование / Инференс

### Загрузка модели:

```bash
curl -X PUT http://<ip>/fs/models/gemma-2b.safetensors --data-binary @gemma-2b.safetensors
curl -X PUT http://<ip>/fs/models/tokenizer.json --data-binary @tokenizer.json
```

### Установка AI-модуля:

```bash
curl -X POST http://<ip>/pkg/install --data-binary @gemma_gpu.rpk
```

### Запрос инференса:

```bash
curl -X POST http://<ip>/ai -d "Что такое Rust?"
```

ОС сама выберет: использовать CPU (через candle) или GPU (через Tesla, если доступна).

---

## 🖥 Взаимодействие через браузер

Операционная система aiSOS поднимает встроенный HTTP-сервер, доступный по IP-серверу.

### 📄 Пример: отправка запроса через веб-форму

```html
<!DOCTYPE html>
<html>
  <body>
    <h1>AI-инференс на aiSOS</h1>
    <textarea id="prompt" rows="4" cols="50">Что такое Rust?</textarea><br>
    <button onclick="ask()">Спросить</button>
    <pre id="result"></pre>

    <script>
      async function ask() {
        const prompt = document.getElementById("prompt").value;
        const res = await fetch("http://<ip>/ai", {
          method: "POST",
          body: prompt
        });
        const text = await res.text();
        document.getElementById("result").innerText = text;
      }
    </script>
  </body>
</html>
```

### 🧪 Альтернатива: использование curl

```bash
curl -X POST http://<ip>/ai -d "расскажи про Rust"
```

---

## 🧩 Создание `.rpk` модулей

```bash
cd rpk/gemma_gpu
cargo build --release
cp target/release/gemma_gpu gemma_gpu.rpk
```

Установить модуль:

```bash
curl -X POST http://<ip>/pkg/install --data-binary @gemma_gpu.rpk
```

---

## 🔄 Сравнение с аналогичными Rust-ОС

| Проект       | Описание                                                                                   | Ссылка                                                                 |
|--------------|--------------------------------------------------------------------------------------------|------------------------------------------------------------------------|
| **Redox OS** | Unix-подобная операционная система на основе микроядра, написанная на Rust.                | [https://www.redox-os.org](https://www.redox-os.org)                   |
| **Tock OS**  | ОС для микроконтроллеров, ориентированная на безопасность и изоляцию.                      | [https://www.tockos.org](https://www.tockos.org)                       |
| **Theseus**  | Исследовательская ОС, написанная на Rust, с акцентом на безопасность и live-upgrade.       | [https://theseus-os.github.io](https://theseus-os.github.io)          |

aiSOS отличается тем, что:

- работает как **серверная платформа** для AI-инференса
- использует **.rpk-модули** для расширения функциональности
- предоставляет **интерфейс через HTTP, WebSocket, файловую систему**
- совместима с GPU (NVIDIA Tesla), но без GUI

---

## 📜 Лицензия

MIT / Apache-2.0